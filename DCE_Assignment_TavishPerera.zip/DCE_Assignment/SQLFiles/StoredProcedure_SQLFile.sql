SELECT Customer.Username, Orders.OrderId, Orders.OrderStatus, Orders.OrderType, Orders.OrderBy, Orders.OrderedOn, Orders.ShippedOn, Orders.IsActive,
Product.ProductId, Product.ProductName, Product.UnitPrice, Product.SupplierId, Product.CreatedOn, Product.IsActive, 
Supplier.SupplierId, Supplier.SupplierName, Supplier.CreatedOn, Supplier.IsActive
From
Customer
INNER JOIN Orders ON Orders.OrderBy = Customer.UserId
INNER JOIN Product ON Product.ProductId = Orders.ProductId
INNER JOIN Supplier ON Supplier.SupplierId = Product.SupplierId
Where Orders.IsActive = 'true' and Customer.UserId = '978B16B1-3333-40F9-A0C7-D5B2FB7DA4CD'


CREATE PROCEDURE 
GetActiveOrdersByCustomer
@UserId uniqueidentifier
AS
SELECT Customer.Username, Orders.OrderId, Orders.OrderStatus, Orders.OrderType, Orders.OrderBy, Orders.OrderedOn, Orders.ShippedOn, Orders.IsActive,
Product.ProductId, Product.ProductName, Product.UnitPrice, Product.SupplierId, Product.CreatedOn, Product.IsActive, 
Supplier.SupplierId, Supplier.SupplierName, Supplier.CreatedOn, Supplier.IsActive
From
Customer
INNER JOIN Orders ON Orders.OrderBy = Customer.UserId
INNER JOIN Product ON Product.ProductId = Orders.ProductId
INNER JOIN Supplier ON Supplier.SupplierId = Product.SupplierId
Where Orders.IsActive = 'true' and Customer.UserId = @UserId

EXEC GetActiveOrdersByCustomer @UserId = '978B16B1-3333-40F9-A0C7-D5B2FB7DA4CD'